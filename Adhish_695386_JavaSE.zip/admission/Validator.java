package admission;

public class Validator {
	  private Validator(){
	   }
	static Validator getValidator() {
	   return new Validator();
	}
	boolean validateStudentDetails(Student student){
	  System.out.println("Documents Validated for "+student.getName());
	  return true;
	}
	   
	}
