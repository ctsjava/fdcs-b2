package com;

import java.util.Scanner;

public class Apply {

	public static void main(String[] args) 
	{
		Student s1 = new Student();
		
		System.out.print("Enter name: ");
		Scanner sc = new Scanner(System.in);
		s1.setName(sc.next());
		s1.setAge(25);
		
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1 + " is " + result);
		
		sc.close();
		
	}

}

