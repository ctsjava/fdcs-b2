package com;

import java.util.Random;

public class Registerar {
    
    private String admissionId;
    
    public static Registerar getRegisterar(){
        return new Registerar();
    }
    
    public String registerStudent(Student student){
        Validator validator=Validator.getValidator();
        if (validator.validateStudentDetails(student)){
            
            Random rnd =new Random();
            int i = rnd.nextInt(999999999);
            admissionId=Integer.toString(i);
            
        }
         return admissionId;   
    }
}
