package com;

public class Student {
    private String name,marStat,sex,pMailId,sMailId,highEduQual,nationality;
    private String admissionId;
    private String result;
    private int age;
    private String dob,address,interstedSubject,phNumber;
public String getMarStat() {
	return marStat;
}

public void setMarStat(String marStat) {
	this.marStat = marStat;
}

public String getSex() {
	return sex;
}

public void setSex(String sex) {
	this.sex = sex;
}

public String getpMailId() {
	return pMailId;
}

public void setpMailId(String pMailId) {
	this.pMailId = pMailId;
}

public String getsMailId() {
	return sMailId;
}

public void setsMailId(String sMailId) {
	this.sMailId = sMailId;
}

public String getHighEduQual() {
	return highEduQual;
}

public void setHighEduQual(String highEduQual) {
	this.highEduQual = highEduQual;
}

public String getNationality() {
	return nationality;
}

public void setNationality(String nationality) {
	this.nationality = nationality;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public String getDob() {
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getInterstedSubject() {
	return interstedSubject;
}

public void setInterstedSubject(String interstedSubject) {
	this.interstedSubject = interstedSubject;
}

public String getPhNumber() {
	return phNumber;
}

public void setPhNumber(String phNumber) {
	this.phNumber = phNumber;
}

private Exam exam;

public Student() {        
    }

public String getName() {
        return name;
    }

public void setName(String name) {
        this.name = name;
    }

public String getAdmissionId() {
        return admissionId;
    }

public void setAdmissionId(String admissionId) {
        this.admissionId = admissionId;
    }

public Exam getExam() {
        return exam;
    }

public void setExam(Exam exam) {
        this.exam = exam;
    }

public String getResult() {
        return result;
    }

public void setResult(String result) {
        this.result = result;
    }
    
    
    
public String registerStudent() {
        Registerar registerar=Registerar.getRegisterar();
        admissionId=registerar.registerStudent(this);
        return admissionId;
    }
    
public void registerForExam() {
        ExamRegisterar examregisterar=ExamRegisterar.getExamRegisterar();
        exam=examregisterar.registeringStudentForExamination(this);
        
    }
    
public void appearForExam(Exam exam){
        Paper paper=exam.getPaper();
        result=paper.submit();
        System.out.println("Student's Result is: "+result);
    }
    
}
