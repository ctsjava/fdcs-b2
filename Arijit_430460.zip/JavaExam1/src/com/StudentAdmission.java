package com;

public class StudentAdmission {
    
    public static void main(String[] args) {
        Student st=new Student();
        
        st.setName("Arijit Sengupta");
        st.setMarStat("Single");
        st.setAge(20);
        st.setAddress("NK-73, Nishikanan, Teghoria");
        st.setDob("03/20/1988");
        st.setSex("Male");
        st.setpMailId("arijit.1@gmail.com");
        st.setsMailId("arijit.2@gmail.com");
        st.setPhNumber("7044562252");
        st.setNationality("Indian");
        st.setHighEduQual("Higher Secondary");
        st.setInterstedSubject("Mathematics");
                    
        st.registerStudent();
        System.out.println("Student's Admission ID is: "+st.getAdmissionId());
        
        st.registerForExam();
        st.appearForExam(st.getExam());
        
        if("Pass".equals(st.getResult())){
            System.out.println("Student has passed the examimnation !!!");
        }
        
    }
}
