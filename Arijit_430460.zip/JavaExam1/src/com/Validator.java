package com;

public class Validator {

    public static Validator getValidator() {
        return new Validator();
    }

    public boolean validateStudentDetails(Student student) {
        System.out.println("Validation Successful !!! for Student "+student.getName());
        return true;
    }
    
}
