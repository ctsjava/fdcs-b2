package com;

/**
 *
 * @author F296s7v
 */
public class Exam {
    
    private Paper paper;
    
    public Exam(Paper paper) {
        this.paper=paper;
    }

    public Paper getPaper() {
        return paper;
    }

    
}
