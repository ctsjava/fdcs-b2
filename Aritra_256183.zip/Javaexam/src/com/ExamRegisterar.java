
package com;

/**
 *
 * @author F296s7v
 */
public class ExamRegisterar {

    public static ExamRegisterar getExamRegisterar() {
        return new ExamRegisterar();
    }
    
    public Exam registeringStudentForExamination(Student student) {
        Paper paper=Paper.getPaper();
        Exam exam=new Exam(paper);
        return exam;
    }
    
}
