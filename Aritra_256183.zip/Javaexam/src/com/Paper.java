package com;

/**
 *
 * @author F296s7v
 */
public class Paper {
	
    private String result;

    public static Paper getPaper() {
        return new Paper();
    }

    public String submit() {
        Evaluator evaluator=Evaluator.getEvaluator();
        result=evaluator.evaluate(this);
        return result;
    }

    
    
}
