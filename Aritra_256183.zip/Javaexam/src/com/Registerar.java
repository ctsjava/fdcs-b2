
package com;

import java.util.Random;


/**
 *
 * @author F296s7v
 */
public class Registerar {
    
    private String admissionId;
    
    public static Registerar getRegisterar(){
        return new Registerar();
    }
    
    public String registerStudent(Student student){
        Validator validator=Validator.getValidator();
        if (validator.validateStudentDetails(student)){
            
            Random rand=new Random();
            int i = rand.nextInt(10000);
            System.out.println("Student "+student.getName()+" registered successfully");
            admissionId=Integer.toString(i);
            
        }
         return admissionId;   
    }
}
