/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author F296s7v
 */
public class Student {
    private String name,mStatus,sex,primaryEmailId,secondaryEmailId,qualification,nationality;
    private int age;
    private String phoneNo,dob,address;
    private String admissionId;
    private String result;
    private Exam exam;

    Student() {        
    }
    
    
    public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getmStatus() {
		return mStatus;
	}


	public void setmStatus(String mStatus) {
		this.mStatus = mStatus;
	}


	public String getSex() {
		return sex;
	}


	public void setSex(String sex) {
		this.sex = sex;
	}


	public String getPrimaryEmailId() {
		return primaryEmailId;
	}


	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}


	public String getSecondaryEmailId() {
		return secondaryEmailId;
	}


	public void setSecondaryEmailId(String secondaryEmailId) {
		this.secondaryEmailId = secondaryEmailId;
	}


	public String getQualification() {
		return qualification;
	}


	public void setQualification(String qualification) {
		this.qualification = qualification;
	}


	public String getNationality() {
		return nationality;
	}


	public void setNationality(String nationality) {
		this.nationality = nationality;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdmissionId() {
        return admissionId;
    }

    public void setAdmissionId(String admissionId) {
        this.admissionId = admissionId;
    }

    public Exam getExam() {
        return exam;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    
    
    
    public String registerStudent() {
        Registerar registerar=Registerar.getRegisterar();
        admissionId=registerar.registerStudent(this);
        return admissionId;
    }
    
    public void registerForExam() {
        ExamRegisterar examregisterar=ExamRegisterar.getExamRegisterar();
        exam=examregisterar.registeringStudentForExamination(this);
        
    }
    
    public void appearForExam(Exam exam){
        Paper paper=exam.getPaper();
        result=paper.submit();
        System.out.println("Result for "+name+" is: "+result);
    }
    
}
