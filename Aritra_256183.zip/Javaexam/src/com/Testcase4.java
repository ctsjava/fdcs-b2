
package com;

public class Testcase4 {
    
    public static void main(String[] args) {
        Student st=new Student();
        
        st.setName("Aritra");
        st.setAge(20);
        st.setmStatus("Single");
        st.setNationality("Indian");
        st.setPhoneNo("9674532797");
        st.setAddress("Naihati");
        st.setDob("25/02/1989");
        st.setPrimaryEmailId("aritra@gmail.com");
        st.setSecondaryEmailId("xyz@gmail.com");
        st.setQualification("10+2");
        
        st.registerStudent();
        System.out.println("Admission ID is: "+st.getAdmissionId());
        
        st.registerForExam();
        st.appearForExam(st.getExam());
        
        if("Pass".equals(st.getResult())){
            System.out.println(st.getName()+" passed in exam successfully");
        }
        
    }
}
