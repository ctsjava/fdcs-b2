/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author F296s7v
 */
public class Validator {

    public static Validator getValidator() {
        return new Validator();
    }

    public boolean validateStudentDetails(Student student) {
        System.out.println("Validation is successful for Student "+student.getName());
        return true;
    }
    
}
