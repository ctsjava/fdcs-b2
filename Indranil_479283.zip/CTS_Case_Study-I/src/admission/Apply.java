package admission;

import java.util.ArrayList;
import java.util.List;

public class Apply {

			public static void main(String[] args) {
			Student s = new Student("Indranil",'U',27,'M',"DD/MM/YYYY","Kolkata","xxx@gmail.com","abc@ymail.com",9000000009l,"ECE","B.Tech","Indian");
			Student s2 = new Student("james",'M',35,'M',"DD/MM/YYYY","Hyderabad","yyy@gmail.com","pqr@ymail.com",8000000008l,"CSE","M.TECE","Indian");
			
			System.out.println("********************************************************");
			
			s.setAdmissionId(s.registerStudent());
			s.registerForExam();
			s.setResult(s.appearForExam());
			//Student.display(s);
			
			//System.out.println("********************************************************");
			
			s2.setAdmissionId(s2.registerStudent());
			s2.registerForExam();
			s2.setResult(s2.appearForExam());
			//Student.display(s2);
			//System.out.println("********************************************************");
			
			List<Student> studList = new ArrayList<>();
			studList.add(s);
			studList.add(s2);
			
			for(Student stud :studList){
				System.out.println("Documents Validated for "+stud.getName());
				Student.display(stud);
				System.out.println("********************************************************");
				
			}

		}

	}


