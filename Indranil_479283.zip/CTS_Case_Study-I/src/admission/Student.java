package admission;

public class Student {
	private String Name; 
	private char MaritalStatus;
	private int Age;
	private char Sex;
	private String DateOfBirth; 
	private String Address;
	private String PrimaryEmailId; 
	private String SecondaryEmailId;
	private long PhoneNumber;
	private String InterestedSubject;
	private String HighestQualification;
	private String Nationality;
	
	private String admissionId;
	private String result;
	private Exam exam; 


	public Student(String name, char maritalStatus, int age, char sex,
			String dateOfBirth, String address, String primaryEmailId,
			String secondaryEmailId, long phoneNumber,
			String interestedSubject, String highestQualification,
			String nationality) {
		Name = name;
		MaritalStatus = maritalStatus;
		Age = age;
		Sex = sex;
		DateOfBirth = dateOfBirth;
		Address = address;
		PrimaryEmailId = primaryEmailId;
		SecondaryEmailId = secondaryEmailId;
		PhoneNumber = phoneNumber;
		InterestedSubject = interestedSubject;
		HighestQualification = highestQualification;
		Nationality = nationality;
	}

	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public char getMaritalStatus() {
		return MaritalStatus;
	}
	public void setMaritalStatus(char maritalStatus) {
		MaritalStatus = maritalStatus;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public char getSex() {
		return Sex;
	}
	public void setSex(char sex) {
		Sex = sex;
	}
	public String getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPrimaryEmailId() {
		return PrimaryEmailId;
	}
	public void setPrimaryEmailId(String primaryEmailId) {
		PrimaryEmailId = primaryEmailId;
	}
	public String getSecondaryEmailId() {
		return SecondaryEmailId;
	}
	public void setSecondaryEmailId(String secondaryEmailId) {
		SecondaryEmailId = secondaryEmailId;
	}
	public long getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getInterestedSubject() {
		return InterestedSubject;
	}
	public void setInterestedSubject(String interestedSubject) {
		InterestedSubject = interestedSubject;
	}
	public String getHighestQualification() {
		return HighestQualification;
	}
	public void setHighestQualification(String highestQualification) {
		HighestQualification = highestQualification;
	}
	public String getNationality() {
		return Nationality;
	}
	public void setNationality(String nationality) {
		Nationality = nationality;
	}
	public String getAdmissionId() {
		return admissionId;
	}
	public void setAdmissionId(String admissionId) {
		this.admissionId = admissionId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Exam getExam() {
		return exam;
	}
	public void setExam(Exam exam) {
		this.exam = exam;
	}
	
	String registerStudent() {
		Registrar registrar = Registrar.getRegistrar();
		admissionId = registrar. registerStudent(this);
		return admissionId;
	}
	
	void registerForExam(){
		ExamRegistrar examRegistrar = ExamRegistrar.getExamRegistrar();
		exam=examRegistrar.registeringStudentForExamination(this);
	}

	String appearForExam(){
		Paper paper = exam.getPaper();
		result = paper.submit();
		return result;
	}
	
	static void display(Student s){

		//System.out.println("********************************************************");
		System.out.println("Name: "+s.getName());
		System.out.println("Primary Email: "+s.getPrimaryEmailId());
		System.out.println("Sex: "+s.getSex());
		System.out.println("Nationality: "+s.getNationality());
		System.out.println("Address: "+s.getAddress());
		System.out.println("Contact no: "+s.getPhoneNumber());
		System.out.println("DOB: "+s.getDateOfBirth());
		System.out.println("Subject applied for: "+s.getInterestedSubject());
		//System.out.println("********************************************************");

		System.out.println("");
		//System.out.println("********************************************************");
		System.out.println("Results of " +s.getName()+ " for the Exam : " +s.getResult());
		System.out.println("Admission ID Geneated: "+s.getAdmissionId());
		//System.out.println("********************************************************");
		;

	}
}

