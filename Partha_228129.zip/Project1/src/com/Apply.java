package com;

import java.util.Scanner;

public class Apply {

	public static void main(String[] args) 
	{
		Student s1 = new Student();
		
		System.out.print("Enter Student's name : ");
		Scanner sc = new Scanner(System.in);
		s1.setName(sc.next());
		
		System.out.print("Enter Student's Age : ");
		s1.setAge(Integer.parseInt(sc.next()));
		
		System.out.print("Enter Address : ");
		s1.setAddress(sc.next());
			 
		
		System.out.print("Enter Email-id : ");
		s1.setEmailid(sc.next());
		
		System.out.print("Enter Nationality : ");
		s1.setNationality(sc.next());
		
		System.out.print("Enter Student's Sex : ");
		s1.setSex(sc.next());
		sc.close(); 
		
		
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1 + " is " + result);
		
		
		
	}

}
