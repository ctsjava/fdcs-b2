package javaexam;

public class Registrar {

	private Registrar(){
		   
	}
	static Registrar getRegistrar(){
	 return new Registrar();
	}

	  String registerStudent(Student student){
	  Validator validator=Validator.getValidator();
	  validator.validateStudentDetails (student);
	  
	  if(validator.validateStudentDetails (student))
	{
		  return student.getName().substring(0,3)+student.hashCode();
	  }
	  return "";
	}

	
}
