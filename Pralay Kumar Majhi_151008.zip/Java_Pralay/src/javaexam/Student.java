package javaexam;

public class Student {

	private String name;
	private String maritalStatus;
	private int age;
	private String sex;
	private String DOB;
	private String address;
	private String emailId;
	private long phoneNumber;
	private String educationQual;
	private String nationality;
	
	public Student(String name, String maritalStatus, int age, String sex,
			String DOB, String address, String emailId, long phoneNumber,
			String educationQual, String nationality) {
		this.name = name;
		this.maritalStatus = maritalStatus;
		this.age = age;
		this.sex = sex;
		this.DOB = DOB;
		this.address = address;
		this.emailId = emailId;
		this.phoneNumber = phoneNumber;
		this.educationQual = educationQual;
		this.nationality = nationality;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEducationQual() {
		return educationQual;
	}

	public void setEducationQual(String educationQual) {
		this.educationQual = educationQual;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	String admissionId;
	String result;
	Exam exam; 
	
		
	void registerStudent() {
		   Registrar registrar=Registrar.getRegistrar();
		admissionId = registrar.registerStudent(this);
		System.out.println("Admission ID :"+admissionId);
		  }

	void registerForExam(){
		 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
		 exam=examRegistrar. registeringStudentForExamination(this);
	}

	String appearForExam(){
		Paper paper=exam.getPaper();
		result=paper.submit();
		return result;
		}
		
		
		
	}
	
	
	
	
	;
	
	
