package javaexam;

public class StudentAdmission {

	public static void main(String[] args) {
	
		Student s=new Student("Pralay",
				"Married",
				35,
				"Male",
				"Aug 08 1983",
				"Howrah",
				"pralay_how@yahoo.co.in",
				9874668956L,
				"B Tech",
				"Indian");
			
		
		s.registerStudent();
		s.registerForExam();
		s.appearForExam();
		
	System.out.println("Result :"+s.result);
		
		}
		
	}
	
		
						
				