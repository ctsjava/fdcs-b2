package javaexam;

public class Validator {

	private Validator(){
	   }
	static Validator getValidator() {
	   return new Validator();
	}
	boolean validateStudentDetails(Student student){
	  
		boolean check = true;
		
		if (student.getName().equals("")){
			check = false;
			System.out.println("Student Name is Blank");
		}
		
		if (student.getMaritalStatus().equals("")){
			check = false;
			System.out.println("Marital Status is Blank");
		}	
		
		if (student.getAge()==0){
			check = false;
			System.out.println("Age is Blank");
		}	
		
		if (student.getSex().equals("")){
			check = false;
			System.out.println("Student Sex is Blank");
		}	
		
		if (student.getDOB().equals("")){
			check = false;
			System.out.println("Student DOB is Blank");
		}	
		
		return check;
		
	
	}
	   
	}
