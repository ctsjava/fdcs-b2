package com;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Student s1=new Student();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Name: ");
        s1.setName(sc.next());
        System.out.println("Enter the MS: ");
        s1.setMs(sc.next());
        System.out.println("Enter the Age: ");
        s1.setAge(sc.nextInt());
        System.out.println("Enter the DOB: ");
        s1.setDob(sc.next());
        System.out.println("Enter the ADD: ");
        s1.setAdd(sc.next());
        System.out.println("Enter the PID: ");
        s1.setPid(sc.next());
        System.out.println("Enter the SID: ");
        s1.setSid(sc.next());
        System.out.println("Enter the PH: ");
        s1.setPh(sc.nextLong());
        System.out.println("Enter the Intsubj: ");
        s1.setIntsub(sc.next());
        System.out.println("Enter the Heq: ");
        s1.setHeq(sc.next());
        System.out.println("Enter the Nation: ");
        s1.setNat(sc.next());
        
        int admissionId = s1.registerStudent();
		System.out.println("Successfuly Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Student result for " + s1 + " is " + result);
        
        sc.close();
	}

}
