package com;

import java.util.Random;

public class Registrar {
	private int id = 0;
	Random rn=new Random();
	int s2 =rn.nextInt(1000000);
	private Registrar()
	{	   
	}
	
	static Registrar getRegistrar()
	{
	 return new Registrar();
	}

	 int registerStudent(Student student)
	 {
	  Validator validator=Validator.getValidator();
	
	  if(validator.validateStudentDetails(student))
	  {
		 id = Integer.valueOf(s2); 
	  }
	  return id;	  
	 }
}
