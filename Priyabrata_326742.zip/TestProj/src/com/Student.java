package com;

public class Student {
	private String name; 
	private String ms;
	private int age;
	private String sex;
	private String dob; 
	private String add;
	private String pid;  
	private String sid;
	private long ph;
	private String intsub;
	private String heq;
	private String nat;
	private int admissionId;
	private String result;
	private Exam exam; 
	Student () 
	{
	 
	}
	int registerStudent() {
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar. registerStudent(this);
	   return admissionId;
	  }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar. registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMs() {
		return ms;
	}
	public void setMs(String ms) {
		this.ms = ms;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public long getPh() {
		return ph;
	}
	public void setPh(long ph) {
		this.ph = ph;
	}
	public String getIntsub() {
		return intsub;
	}
	public void setIntsub(String intsub) {
		this.intsub = intsub;
	}
	public String getHeq() {
		return heq;
	}
	public void setHeq(String heq) {
		this.heq = heq;
	}
	public String getNat() {
		return nat;
	}
	public void setNat(String nat) {
		this.nat = nat;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", ms=" + ms + ", age=" + age + ", sex=" + sex + ", dob=" + dob + ",add=" + add + ", pid=" + pid + ", sid=" + sid + ", ph=" + ph + ", intsub=" + intsub + ", heq=" + heq + ", nat=" + nat + "]";
	}

}
