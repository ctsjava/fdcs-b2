package com;

public class Evaluator {

	private String result;
    public void setResult(String result) {
    	this.result = result;
    }

    static Evaluator getEvaluator(){
      return new Evaluator();
      }

    String evaluate(Paper paper){
    	return "Pass";
    	}
}
