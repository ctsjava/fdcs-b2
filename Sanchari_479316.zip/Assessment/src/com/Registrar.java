package com;

public class Registrar {
	
    private String admissionId;
    
    static Registrar getRegistrar() {
    return new Registrar();
    }

    String registerStudent(Student student){
      Validator validator=Validator.getValidator();
      if(validator.validateStudentDetails(student))
      {
    	  admissionId = Integer.toString(student.hashCode());
       }
      return admissionId;       
     }
}


