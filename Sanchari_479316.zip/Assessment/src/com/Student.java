package com;

public class Student {

    private String name;
    private String maritalStatus;
    private int age;
    private char sex;
    private String dob;
    private String address;
    private String primaryEmailId;
    private String secondaryEmailId;
    private int phoneNumber;
    private String educationQual;
    private String nationality;

    private String admissionId;
    private String result;
    private Exam exam;

    
    String registerStudent(){
       Registrar registrar=Registrar.getRegistrar();
       admissionId = registrar.registerStudent(this);
       return admissionId;
    }

    String registerForExam(){
    ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
    exam=examRegistrar.registeringStudentForExamination(this);
    return "registered for exam";
    }

    String appearForExam(){
    Paper paper=exam.getPaper();
    result=paper.submit();
    return result;
    }
    
    public String getName() {
    	return name;
    }

    public void setName(String name) {
    	this.name = name;
    }

    public String getMaritalStatus() {
    	return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public int getAge() {
    	return age;
    }

    public void setAge(int age) {
           this.age = age;
    }

    public char getSex() {
           return sex;
    }

    public void setSex(char sex) {
           this.sex = sex;
    }

    public String getDob() {
           return dob;
    }

    public void setDob(String dob) {
           this.dob = dob;
    }

    public String getAddress() {
           return address;
    }

    public void setAddress(String address) {
           this.address = address;
    }

    public String getPrimaryEmailId() {
           return primaryEmailId;
    }

    public void setPrimaryEmailId(String primaryEmailId) {
           this.primaryEmailId = primaryEmailId;
    }

    public String getSecondaryEmailId() {
           return secondaryEmailId;
    }

    public void setSecondaryEmailId(String secondaryEmailId) {
           this.secondaryEmailId = secondaryEmailId;
    }

    public int getPhoneNumber() {
           return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
           this.phoneNumber = phoneNumber;
    }

    public String getEducationQual() {
           return educationQual;
    }

    public void setEducationQual(String educationQual) {
           this.educationQual = educationQual;
    }

    public String getNationality() {
           return nationality;
    }

    public void setNationality(String nationality) {
           this.nationality = nationality;
    }

    public String getAdmissionId() {
           return admissionId;
    }

    public void setAdmissionId(String admissionId) {
           this.admissionId = admissionId;
    }

    public String getResult() {
           return result;
    }

    public void setResult(String result) {
           this.result = result;
    }

    public Exam getExam() {
           return exam;
    }

    public void setExam(Exam exam) {
           this.exam = exam;
    }
}

