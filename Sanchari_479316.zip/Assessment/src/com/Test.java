package com;

public class Test {

    public static void main(String[] args){
    	
    	Student s1=new Student();
    	    	
    	s1.setName("Sanchari");
    	s1.setMaritalStatus("Unmarried");
    	s1.setAge(27);
    	s1.setSex('F');
    	s1.setDob("28-09-1991");
    	s1.setAddress("Kasba, Kolkata");
    	s1.setPrimaryEmailId("sanchari1@gmail.com");
    	s1.setSecondaryEmailId("sanchari2@gmail.com");
    	s1.setPhoneNumber(1234);
    	s1.setEducationQual("B.Tech");
    	s1.setNationality("Indian");
    	s1.setAdmissionId(s1.registerStudent());
    	
    	Evaluator e1=new Evaluator();
    	
    	System.out.println("Student Full Information :");
    	System.out.println("Name:"+s1.getName());
    	System.out.println("Marital Status:"+s1.getMaritalStatus());
    	System.out.println("Age:"+s1.getAge());
    	System.out.println("Sex:"+s1.getSex());
    	System.out.println("Date of Birth:"+s1.getDob());
    	System.out.println("Address:"+s1.getAddress());
    	System.out.println("Primary Email ID:"+s1.getPrimaryEmailId());
    	System.out.println("Secondary email ID:"+s1.getSecondaryEmailId());
    	System.out.println("Phone Number:"+s1.getPhoneNumber());
    	System.out.println("Highest Educational Qualification:"+s1.getEducationQual());
    	System.out.println("Nationality:"+s1.getNationality());
    	System.out.println("  ");
    	
        System.out.println("Admission Details :");
    	System.out.println("Registered " + s1.getName() + " with ID: " + s1.getAdmissionId());
    	System.out.println(s1.getName() + " " + s1.registerForExam());
    	s1.appearForExam();
    	System.out.println("Result for " + s1.getName() + " is " + s1.getResult());
    	System.out.println("-------------------------");
    	
    	Student s2=new Student();
    	
    	s2.setName("Sam");
    	s2.setMaritalStatus("Unmarried");
    	s2.setAge(26);
    	s2.setSex('F');
    	s2.setDob("01-10-1992");
    	s2.setAddress("NewTown, Kolkata");
    	s2.setPrimaryEmailId("sam1@gmail.com");
    	s2.setSecondaryEmailId("sam2@gmail.com");
    	s2.setPhoneNumber(5678);
    	s2.setEducationQual("B.Tech");
    	s2.setNationality("Indian");
    	
    	Evaluator e2=new Evaluator();
    	
    	System.out.println("Student Full Information :");
    	System.out.println("Name:"+s2.getName());
    	System.out.println("Marital Status:"+s2.getMaritalStatus());
    	System.out.println("Age:"+s2.getAge());
    	System.out.println("Sex:"+s2.getSex());
    	System.out.println("Date of Birth:"+s2.getDob());
    	System.out.println("Address:"+s2.getAddress());
    	System.out.println("Primary Email ID:"+s2.getPrimaryEmailId());
    	System.out.println("Secondary Email ID:"+s2.getSecondaryEmailId());
    	System.out.println("Phone Number:"+s2.getPhoneNumber());
    	System.out.println("Highest Educational Qualification:"+s2.getEducationQual());
    	System.out.println("Nationality:"+s2.getNationality());
    	s2.setAdmissionId(s2.registerStudent());
    	
    	System.out.println("Admission Details :");
    	System.out.println("Registered " + s2.getName() + " with ID: " + s2.getAdmissionId());
    	System.out.println(s2.getName() + " " + s2.registerForExam());
    	s2.appearForExam();
    	System.out.println("Result for " + s2.getName() + " is " + s2.getResult());
    	System.out.println("-------------------------");
    }
}


