package com;

import java.util.Scanner;

public class Apply {

	public static void main(String[] args) 
	{

		System.out.println("    WELCOME TO ABC UNIVERSITY STUDENT REGISTER PORTAL   ");
		System.out.println("========================================================");
		Student s1 = new Student();
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter name: ");
		s1.setName(sc.next());
		System.out.print("Enter sex: ");
		s1.setSex(sc.next());
		System.out.print("Enter age: ");
		s1.setAge(Integer.parseInt(sc.next()));
		System.out.print("Enter date of birth: ");
		s1.setDob(sc.next());
		System.out.print("Enter marital status: ");
		s1.setMaritalstatus(sc.next());
		System.out.print("Enter address: ");
		s1.setAddress(sc.next());
		System.out.print("Enter email id: ");
		s1.setMailid(sc.next());
		System.out.print("Enter nationality: ");
		s1.setNationality(sc.next());
		sc.close();
		
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1 + " is " + result);
		
		
		
	}

}
