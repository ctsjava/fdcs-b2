package com;

public class Student 
{

	private String name;
	private String sex;
	private int age;
	private String maritalstatus;
	private String dob;
	private String address;
	private String mailid;
	private double mobile;
	private String nationality;
	private String eduqualification;
	
	private int admissionId;
	private String result;
	private Exam exam; 
	
	public Student() 
	{	
	}
	
	int registerStudent() 
	{
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	   return admissionId;
	 }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}
    
	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getMaritalstatus() {
		return maritalstatus;
	}

	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public double getMobile() {
		return mobile;
	}


	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getEduqualification() {
		return eduqualification;
	}
	public void setMobile(double mobile) {
		this.mobile = mobile;
	}


	public void setEduqualification(String eduqualification) {
		this.eduqualification = eduqualification;
	}

	@Override
	public String toString() {
		return "Student [Name:" + name + ", Age:" + age + "]";
	}

	
}
