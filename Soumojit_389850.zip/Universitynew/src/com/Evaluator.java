
package com;


public class Evaluator {

    static Evaluator getEvaluator() {
        return new Evaluator();
        
    }
    
    public String evaluate(Paper paper){
        
        return "Pass";
    }
}
