package com;


public class Exam {
    
    Paper paper;
    
    public Exam(Paper paper) {
        this.paper=paper;
    }

    public Paper getPaper() {
        return paper;
    }
}
    