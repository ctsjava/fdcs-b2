package com;

import java.util.*;
public class Main {
    

   


    public static void main(String[] args) {
    
    	
    	Scanner sc =new Scanner(System.in);
    
    	System.out.println("Please enter your name ");
    	String nameStudent=sc.nextLine();
    	
    	System.out.println("Please enter your age ");
    	short age = sc.nextShort();
    	
    	System.out.println("Marital Status   S -Single / M -Married ");
    	char maritalStatus = sc.next().charAt(0);
    	
    	System.out.println("Sex (M/F) : ");
    	char sex = sc.next().charAt(0);
    	
    	System.out.println("What is your Primary Email id : ");
    	String primaryEmailId = sc.next();
    	
    	System.out.println("What is your Highest Education Qualification : ");
    	String highestEducationQualification = sc.next();
    	
    	
    	
        Student st=new Student();
        st.setName(nameStudent);
        st.registerStudent();
     
        System.out.println("Admission ID is: "+st.getAdmissionId());
        
        st.registerForExam();
        st.appearForExam(st.getExam());
        
        if("Pass".equals(st.getResult())){
            System.out.println("Student passed in exam successfully");
        }     
        
        System.out.println("Do you want to seen in details : press Y or N");
        char cond = sc.next().charAt(0);
        if (cond == 'Y' || cond == 'y')
         {
          	System.out.println("Age : " + age);	
           	System.out.println("Marital Status : " + maritalStatus);	
           	System.out.println("Sex : " + sex);	
           	System.out.println("Primary Email id : " + primaryEmailId);	
           	System.out.println("Highest Education Qualification : " + highestEducationQualification);	
         }
        else if (cond == 'N' || cond == 'n')
           	System.out.println("Thank you");
       
        sc.close();
    }
}
