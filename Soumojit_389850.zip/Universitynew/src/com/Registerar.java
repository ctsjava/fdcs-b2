package com;



import java.util.Random;



public class Registerar {
    
    String admissionId;
    
    public static Registerar getRegisterar(){
        return new Registerar();
    }
    
    public String registerStudent(Student student){
        Validator valid=Validator.getValidator();
        if (valid.validateStudentDetails(student)){
            
            Random rand=new Random();
            int admission = rand.nextInt(100);
            admissionId=Integer.toString(admission);
            
        }
         return admissionId;   
    }
}
