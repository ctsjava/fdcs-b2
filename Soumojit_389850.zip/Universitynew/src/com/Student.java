package com;

public class Student {
    private String name;
    private String admissionId;
    private String result;
    private Exam exam;

    Student() {        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdmissionId() {
        return admissionId;
    }

    public void setAdmissionId(String admissionId) {
        this.admissionId = admissionId;
    }

    public Exam getExam() {
        return exam;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    
    
    
    public String registerStudent() {
        Registerar registerar=Registerar.getRegisterar();
        admissionId=registerar.registerStudent(this);
        return admissionId;
    }
    
    public void registerForExam() {
        ExamRegisterar examregisterar=ExamRegisterar.getExamRegisterar();
        exam=examregisterar.registeringStudentForExamination(this);
        
    }
    
    public void appearForExam(Exam exam){
        Paper paper=exam.getPaper();
        result=paper.submit();
        System.out.println("Result is: "+result);
    }
    
}
