
package com;


public class Validator {

    public static Validator getValidator() {
        return new Validator();
    }

    public boolean validateStudentDetails(Student student) {
        
    	System.out.println();
    	System.out.println("Validation successfull for  "+student.getName());
        
        System.out.println("Name : "+ student.getName());
        return true;
    }
    
}