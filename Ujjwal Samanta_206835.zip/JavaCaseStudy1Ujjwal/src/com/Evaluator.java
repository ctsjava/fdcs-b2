package com;

public class Evaluator {

	private static Evaluator evaluator; 
	
private Evaluator(){}
	
	public static Evaluator getEvaluator()
	{
		System.out.println("Evaluator is identified to evaluate the examination paper...");
		if (evaluator == null)
		{
			evaluator = new Evaluator();
			return evaluator;
		}
		else{
			return evaluator;
		}
		
			
	}
	
	public String evaluatePaper(Paper paper){
		System.out.println("Examination Evaluator evaluating "+paper.paperName+" examination paper..");
		System.out.println(paper.paperName+" examination paper evaluation is successfull..");
		return "pass";
	}
	
}
