package com;

public class Exam {

	Paper paper;
	
	public Exam(Paper paper){
		this.paper=paper;
		System.out.println(paper.paperName+" question paper is set for examination");
	}
	
	public Paper getPaper()
	{
		System.out.println(paper.paperName+" question paper is given to the student");
		return paper;
	}
}
