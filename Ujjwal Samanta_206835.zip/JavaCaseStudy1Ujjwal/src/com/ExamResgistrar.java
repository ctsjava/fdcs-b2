package com;

public class ExamResgistrar {

private static ExamResgistrar examRegistrar; 
	
	private ExamResgistrar(){}
	
	public static ExamResgistrar getExamResgistrar()
	{
		System.out.println("Examination Registration proecss is initiated, Examination Registrar is notified");
		if (examRegistrar == null)
		{
			examRegistrar = new ExamResgistrar();
			return examRegistrar;
		}
		else{
			return examRegistrar;
		}
			
	}
	
	public Exam registeringStudentForExamination (Student student){
		System.out.println("Examination Registrar is setting examination paper for "+student.getStudentName());
		Paper paper=new Paper("MCQ");
		Exam exam=new Exam(paper);
		return exam;
	}
	
}
