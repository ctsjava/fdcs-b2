package com;

public class Paper {

	String paperName;
	
	Paper(String paperName){
		this.paperName=paperName;
		System.out.println("Question Paper "+paperName+" is created");
		
	}
	
	public String submitPaper(){
		Evaluator evaluator=Evaluator.getEvaluator();
		System.out.println("Submitted Examination papper is passed to the evaluator...");
		String evaluationResult=evaluator.evaluatePaper(this);
		return evaluationResult;
	}
	
	
}
