package com;

public class Registrar {
	
	private static Registrar registrar; 
	
	private Registrar(){}
	
	public static Registrar getRegistrar()
	{
		System.out.println("Registration proecss is initiated, University Registrar is notified");
		if (registrar == null)
		{
			registrar = new Registrar();
			return registrar;
		}
		else{
			return registrar;
		}
	 
	}
	
	public String registerStudent(Student stud){
		Validator validator=Validator.getValidator();
		boolean studentAdmission=validator.validateStudentDetails(stud);
		if (studentAdmission){
			System.out.println("Student details are validated and good for admission");
			return stud.getStudentName().substring(0, 5)+stud.hashCode();
		}
		else{
			
			System.out.println("Validaiton failed during validating Student details");
			return "";
		}
		
		
	}
	
}
