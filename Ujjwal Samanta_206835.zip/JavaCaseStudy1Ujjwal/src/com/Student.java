package com;

public class Student {

	private String StudentName, studentMaritalStatus, studentSex, studentDOB, studentAddress, studentPrimaryEmailid, studentSecondaryEmailid;
	private String studentHighestEducationQualification,studentNationality;
	private long studentPhoneNumber;
	private byte studentAge;
	
	private String stduentAdmissionId;
	private String evaluationResult;
	Exam exam;
	
	public Student(String studentName, String studentMaritalStatus,
			String studentSex, String studentDOB, String studentAddress,
			String studentPrimaryEmailid, String studentSecondaryEmailid,
			String studentHighestEducationQualification,
			String studentNationality, long studentPhoneNumber,
			byte studentAge) {
		System.out.println("Student details received for admission");
		this.StudentName = studentName;
		this.studentMaritalStatus = studentMaritalStatus;
		this.studentSex = studentSex;
		this.studentDOB = studentDOB;
		this.studentAddress = studentAddress;
		this.studentPrimaryEmailid = studentPrimaryEmailid;
		this.studentSecondaryEmailid = studentSecondaryEmailid;
		this.studentHighestEducationQualification = studentHighestEducationQualification;
		this.studentNationality = studentNationality;
		this.studentPhoneNumber = studentPhoneNumber;
		this.studentAge = studentAge;
	}

	public String getStudentName() {
		return StudentName;
	}

	public void setStudentName(String studentName) {
		this.StudentName = studentName;
	}

	public String getStudentMaritalStatus() {
		return studentMaritalStatus;
	}

	public void setStudentMaritalStatus(String studentMaritalStatus) {
		this.studentMaritalStatus = studentMaritalStatus;
	}

	public String getStudentSex() {
		return studentSex;
	}

	public void setStudentSex(String studentSex) {
		this.studentSex = studentSex;
	}

	public String getStudentDOB() {
		return studentDOB;
	}

	public void setStudentDOB(String studentDOB) {
		this.studentDOB = studentDOB;
	}

	public String getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}

	public String getStudentPrimaryEmailid() {
		return studentPrimaryEmailid;
	}

	public void setStudentPrimaryEmailid(String studentPrimaryEmailid) {
		this.studentPrimaryEmailid = studentPrimaryEmailid;
	}

	public String getStudentSecondaryEmailid() {
		return studentSecondaryEmailid;
	}

	public void setStudentSecondaryEmailid(String studentSecondaryEmailid) {
		this.studentSecondaryEmailid = studentSecondaryEmailid;
	}

	public String getStudentHighestEducationQualification() {
		return studentHighestEducationQualification;
	}

	public void setStudentHighestEducationQualification(
			String studentHighestEducationQualification) {
		this.studentHighestEducationQualification = studentHighestEducationQualification;
	}

	public String getStudentNationality() {
		return studentNationality;
	}

	public void setStudentNationality(String studentNationality) {
		this.studentNationality = studentNationality;
	}

	public long getStudentPhoneNumber() {
		return studentPhoneNumber;
	}

	public void setStudentPhoneNumber(long studentPhoneNumber) {
		this.studentPhoneNumber = studentPhoneNumber;
	}

	public byte getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(byte studentAge) {
		this.studentAge = studentAge;
	}

	public String registarStudent(){
		Registrar registrar=Registrar.getRegistrar();
		stduentAdmissionId=registrar.registerStudent(this);
		if(!stduentAdmissionId.equals("")){
			System.out.println("Student Admission ID is "+stduentAdmissionId);	
		}
		return stduentAdmissionId;
	}
	
	public void registarForExam(){
		ExamResgistrar examRegistrar=ExamResgistrar.getExamResgistrar();
		exam=examRegistrar.registeringStudentForExamination(this);
	}
	
	public String appearForExam(){
		Paper paper=exam.getPaper();
		System.out.println("Student is submitting the Examination papper is passed to the evaluator...");
		String evaluationResult=paper.submitPaper();
		return evaluationResult;
				
	}
	
}
