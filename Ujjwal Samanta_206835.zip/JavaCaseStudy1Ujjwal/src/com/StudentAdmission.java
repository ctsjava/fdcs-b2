package com;

public class StudentAdmission {

	public static void main(String[] args) {
		
		String admissionId;
		String evaluationResult;
		Student student1=new Student("Ujjwal Samanta","married","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","Indian",9748526267L,(byte)32);
		admissionId=student1.registarStudent();
		if (!admissionId.equals(""))
		{
			student1.registarForExam();
			evaluationResult=student1.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
	
		System.out.println("-------------------------------");
		
		Student student2=new Student("","married","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","Indian",9748526267L,(byte)32);
		admissionId=student2.registarStudent();
		if (!admissionId.equals(""))
		{
			student2.registarForExam();
			evaluationResult=student2.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
	
		System.out.println("-------------------------------");
		
		Student student3=new Student("Ujjwal Samanta","","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","Indian",9748526267L,(byte)32);
		admissionId=student3.registarStudent();
		if (!admissionId.equals(""))
		{
			student3.registarForExam();
			evaluationResult=student3.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
	
		System.out.println("-------------------------------");
		
		Student student4=new Student("Ujjwal Samanta","married","","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","Indian",9748526267L,(byte)32);
		admissionId=student4.registarStudent();
		if (!admissionId.equals(""))
		{
			student4.registarForExam();
			evaluationResult=student4.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
		System.out.println("-------------------------------");
		
		Student student5=new Student("Ujjwal Samanta","married","male","",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","Indian",9748526267L,(byte)32);
		admissionId=student5.registarStudent();
		if (!admissionId.equals(""))
		{
			student5.registarForExam();
			evaluationResult=student5.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
		
		System.out.println("-------------------------------");
		
		Student student6=new Student("Ujjwal Samanta","married","male","05/01/1986",
                "","abc@gmail.com","",
                "Masters","Indian",9748526267L,(byte)32);
		admissionId=student6.registarStudent();
		if (!admissionId.equals(""))
		{
			student6.registarForExam();
			evaluationResult=student6.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
		System.out.println("-------------------------------");
		
		Student student7=new Student("Ujjwal Samanta","married","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","","",
                "Masters","Indian",9748526267L,(byte)32);
		admissionId=student7.registarStudent();
		if (!admissionId.equals(""))
		{
			student7.registarForExam();
			evaluationResult=student7.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
		System.out.println("-------------------------------");
		
		Student student8=new Student("Ujjwal Samanta","married","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "","Indian",9748526267L,(byte)32);
		admissionId=student8.registarStudent();
		if (!admissionId.equals(""))
		{
			student8.registarForExam();
			evaluationResult=student8.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
		
		System.out.println("-------------------------------");
		
		Student student9=new Student("Ujjwal Samanta","married","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","",9748526267L,(byte)32);
		admissionId=student9.registarStudent();
		if (!admissionId.equals(""))
		{
			student9.registarForExam();
			evaluationResult=student9.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
		
		System.out.println("-------------------------------");
		
		Student student10=new Student("Ujjwal Samanta","married","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","Indian",0,(byte)32);
		admissionId=student10.registarStudent();
		if (!admissionId.equals(""))
		{
			student10.registarForExam();
			evaluationResult=student10.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}
		
		System.out.println("-------------------------------");
		
		Student student11=new Student("Ujjwal Samanta","married","male","05/01/1986",
                "Kishorepur,Hooghly,PIN=712617","abc@gmail.com","",
                "Masters","Indian",9748526267L,(byte)0);
		admissionId=student11.registarStudent();
		if (!admissionId.equals(""))
		{
			student11.registarForExam();
			evaluationResult=student11.appearForExam();
			System.out.println("Examination process is completed, result is "+evaluationResult);
		}
		else
		{
			System.out.println("Student details not correct for admission");
		}

	}

}
