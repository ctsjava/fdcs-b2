package com;

public class Validator {

private static Validator validator; 
	
	private Validator(){}
	
	public static Validator getValidator()
	{
		System.out.println("Student Details is sent for validation.....");
		if (validator == null)
		{
			validator = new Validator();
			return validator;
		}
		else{
			return validator;
		}
			
	}
	
	public boolean validateStudentDetails(Student student){
		System.out.println("Student Details validation is in progress.....");
		boolean studentDetailsCorrect=true;
		
		if (student.getStudentName().equals("")){
			System.out.println("Student name is invalid");
			studentDetailsCorrect=false;
		}
		
		
		if (	(!student.getStudentMaritalStatus().equals("married") &&
				 !student.getStudentMaritalStatus().equals("single"))
			){
			System.out.println("Student marital status is invalid");
			studentDetailsCorrect=false;
		}
		
		
		if (	(!student.getStudentSex().equals("male") &&
				 !student.getStudentSex().equals("female"))
			){
			System.out.println("Student sex is invalid");
			studentDetailsCorrect=false;
		}
		
		
		if (student.getStudentDOB().equals("")){
			System.out.println("Student date of birth is invalid");
			studentDetailsCorrect=false;
		}
		
		
		if (student.getStudentAddress().equals("")){
			System.out.println("Student Address is invalid");
			studentDetailsCorrect=false;
		}
		
		if (student.getStudentPrimaryEmailid().equals("")){
			System.out.println("Student Prinary Email address is invalid");
			studentDetailsCorrect=false;
		}
		
		if (student.getStudentHighestEducationQualification().equals("")){
			System.out.println("Student Highest Education Qualification is invalid");
			studentDetailsCorrect=false;
		}
		
		if (student.getStudentNationality().equals("")){
			System.out.println("Student nationality is invalid");
			studentDetailsCorrect=false;
		}
		
		if (student.getStudentPhoneNumber()==0){
			System.out.println("Student phone number is invalid");
			studentDetailsCorrect=false;
		}
		
		if (student.getStudentAge()==0){
			System.out.println("Student Age is invalid");
			studentDetailsCorrect=false;
		}
		
		return studentDetailsCorrect;
		
	}
}
