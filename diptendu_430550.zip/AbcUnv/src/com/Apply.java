package com;



public class Apply {

	public static void main(String[] args) 
	{
		Student s1 = new Student();
		Student s2=  new Student();
		

		
		s1.setName("Diptendu");
		s1.setMaritalStat("unmarried");
		s1.setAge(28);
		s1.setSex("male");
		s1.setDOB(16111990);
		s1.setAddress("Prafulla chaki road");
		s1.setPemail("diptendukumarkundu@gmail.com");
		s1.setSemail("diptendu.kundu@gmail.com");
		s1.setMobno(25777613);
		s1.setInsub("Robotics");
		s1.setHighestqualification("b.tech");
		s1.setNationality("indian");
		
		
		s2.setName("Saurav");
		s2.setMaritalStat("unmarried");
		s2.setAge(27);
		s2.setSex("male");
		s2.setDOB(16111991);
		s2.setAddress("Krishnanagore");
		s2.setPemail("diptendukumarkundu@gmail.com");
		s2.setSemail("diptendu.kundu@gmail.com");
		s2.setMobno(25777613);
		s2.setInsub("Robotics");
		s2.setHighestqualification("b.tech");
		s2.setNationality("indian");
		
			
		int admissionId = s1.registerStudent();
		System.out.println("Registered " + s1 + " with ID: " + admissionId);
		
		System.out.println(s1 + " " + s1.registerForExam());
		
		String result = s1.appearForExam();
		System.out.println("Result for " + s1 + " is " + result);
		
		
		int admissionId2 = s2.registerStudent();
		System.out.println("Registered " + s2 + " with ID: " + admissionId2);
		
		System.out.println(s2 + " " + s2.registerForExam());
		
		String result2 = s2.appearForExam();
		System.out.println("Result for " + s2 + " is " + result2);
		
		
		
		
	}

}
