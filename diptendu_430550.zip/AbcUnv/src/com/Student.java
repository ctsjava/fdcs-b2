package com;

public class Student 
{

	private String name; 
	private int age;
	private String  maritalStat;
	private String  sex;
	private int DOB;	
	private String address;
	private String pemail;
	private String Semail;
	private int mobno;
	private String insub;
	private String highestqualification;
	private String nationality; 
	
	private int admissionId;
	private String result;
	private Exam exam; 
	
	public Student() 
	{	
	}
	
	int registerStudent() 
	{
	   Registrar registrar=Registrar.getRegistrar();
	   admissionId = registrar.registerStudent(this);
	   return admissionId;
	 }

	String registerForExam()
	{
	 ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
	 exam=examRegistrar.registeringStudentForExamination(this);
	 return "registered for exam";
	}

	String appearForExam()
	{
	Paper paper=exam.getPaper();
	result=paper.submit();
	return result;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public String getMaritalStat() {
		return maritalStat;
	}

	public void setMaritalStat(String maritalStat) {
		this.maritalStat = maritalStat;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getDOB() {
		return DOB;
	}

	public void setDOB(int dOB) {
		DOB = dOB;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPemail() {
		return pemail;
	}

	public void setPemail(String pemail) {
		this.pemail = pemail;
	}

	public String getSemail() {
		return Semail;
	}

	public void setSemail(String semail) {
		Semail = semail;
	}

	public int getMobno() {
		return mobno;
	}

	public void setMobno(int mobno) {
		this.mobno = mobno;
	}

	public String getInsub() {
		return insub;
	}

	public void setInsub(String insub) {
		this.insub = insub;
	}

	public String getHighestqualification() {
		return highestqualification;
	}

	public void setHighestqualification(String highestqualification) {
		this.highestqualification = highestqualification;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", dateob=" + DOB +",Sex=" + sex +"]";
	}

	
}
